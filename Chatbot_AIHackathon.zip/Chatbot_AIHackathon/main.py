from flask import Flask, render_template, jsonify, request
import random, json


app = Flask(__name__)


@app.route('/')
@app.route('/home')
def homepage():
    return render_template('index.html')

@app.route('/chatMessage/', methods=['POST'])
def messageReceived():
    message = request.form.get('data')
    response = ""
    greetings = ["Hello There", "Hey", "Hi", "Hello", "Hey There"]
    data = loadJSON()

    if message.lower() in [x.lower() for x in greetings]:
        #data = {}
        #data['users'] = []
        data['users'].append({
            'id': 'userid',
            'state': 1
        })
        saveJSON(data)
        response = random.choice(greetings) + "! May I know who are you calling for? <br><br> 1 - For Yourself <br> 2 - For Others"
        return response



    for u in data['users']:
        if u['id'] == 'userid':
            if u['state'] == 1:
                if int(message) == 1:
                    response = "Please provide your information: <br> Name:"
                    u['state'] = 2
                    saveJSON(data)
                elif int(message) == 2:
                    response = "For Others"
                else:
                    response = "Please choose from the choices."
            elif u['state'] == 2:
                u['state'] = 3
                u['yourname'] = message
                response = "Email:"
                saveJSON(data)
            elif u['state'] == 3:
                u['state'] = 4
                u['youremail'] = message
                response = "Contact No:"
                saveJSON(data)
            elif u['state'] == 4:
                u['state'] = 5
                u['yourcontactno'] = message
                response = "Supervisor:"
                saveJSON(data)
            elif u['state'] == 5:
                u['state'] = 6
                u['yoursupervisor'] = message
                saveJSON(data)
                response = "Okay great! I have now consolidated and verified the given information.<br><br> Name: "+ u['yourname'] + "<br> Email: "+ u['youremail'] + "<br> Contact No: "+ u['yourcontactno'] + "<br> Supervisor: "+ u['yoursupervisor']






    return response;

def saveJSON(data):
    with open('data.txt', 'w') as outfile:
        json.dump(data, outfile)

def loadJSON():
    with open('data.txt') as json_file:
        data = json.load(json_file)
        return data

if __name__ == '__main__':
    app.run(debug=True)